package com.example.batalla_naval

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
